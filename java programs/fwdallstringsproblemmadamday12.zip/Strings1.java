import java.util.*;
class Strings1
{
	public static void main(String args[])
	{
	String s1="Welcome to Java World";
	System.out.println(s1.charAt(5));
	String s2="Welcome";
	int y=s1.compareTo(s2);
	System.out.println(y);
	String s3="Let us learn";
	System.out.println(s1.concat(s3));
	System.out.println(s1.substring(4,11));
	System.out.println(s1.toLowerCase());
	System.out.println(s1.replace('a','e'));
	}
}